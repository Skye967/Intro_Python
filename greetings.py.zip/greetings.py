myname = "Skye"
arr = []
while len(arr) < 10:
    value = input("Please enter a name:\n")
    for i in arr:
        while(value == i):
            print("Name is already given")
            value = input("Use different Name:")
    arr.append(value)
print("It was nice to meet you all.")
    