computercount = 0
Humancount = 0
for i in range(0,5):
    Human = input("choose rock, paper, or scissors:")
    print("Human chooses" + " " + Human)
    if( Human == "rock"):
        Human = 2
    if( Human == "paper"):
        Human = 1
    if( Human == "scissors"):
        Human = 0
    if(Human >= 0):
        import random
    computer = random.randint(0,2)
    if(computer == 2):
        print("computer chooses rock")
    if(computer == 1):
        print("computer chooses paper")
    if(computer == 0):
        print("computer chooses scissors")
    if( Human == 0 and computer ==1):
        print("you win!")
        Humancount += 1
    if( Human == 1 and computer ==2):
        print("you win!")
        Humancount += 1
    if( Human == 2 and computer ==0):
        print("you win!")
        Humancount += 1
    if( Human == 0 and computer ==2):
        print("you lose!")
        computercount += 1
    if( Human == 1 and computer ==0):
        print("you lose!")
        computercount += 1
    if( Human == 2 and computer ==1):
        print("you lose!")
        computercount += 1
    if( Human == computer):
        print("It's a tie!")
    if(computercount >= 3 and Humancount >=3):
        break
    