
arr = []
def countdown(number):
    for i in range(number,0,-1):
        arr.append(i)
        print(i)
countdown(10)

def printAndReturn(arr):
    for i in range(0,len(arr), +1):
        print(arr[0])
        return arr[1]
print(printAndReturn([1,2]))

sum = 0
def firstPlusLength(arr):
    sum = arr[0] + len(arr)
    print(sum)
firstPlusLength([1,2,3,4,5])

def valuesGreaterThanSecond(arr):
    arr2 = []
    for i in range(0,len(arr)+1, +1):
        if(i >= arr[1]):
            arr2.append(i)
    print(len(arr2))
    return arr2
print(valuesGreaterThanSecond([1,2,3,4,5,6]))


def thisLengthThatValue(a,b):
    arr = []
    for i in range(0,a, +1):
        arr.append(b)
    return arr
print(thisLengthThatValue(5,2))
