#for i in range(1, 150):
    #print(i)
 
sum1 = 0
for i in range(1,1000):
    if(i % 5 == 0):
        sum1 += i
        print(sum1)
    
sum2 = 0
for i in range(1,1000):
    if(i % 5 == 0):
        sum2 += i
        print("coding")
    if(i % 10 == 0):
        sum2 += i
        print("coding dojo")
        
sum3 = 0
for i in range(1,500000):
    if(i % 2 == 1):
        sum3 =+ i        
print(sum3)

sum4 = 2018
for i in range(2018, 0, -4):
    print(i)


lowNum = 3
highNum = 9
lowNum = 2
for i in range(2, 9, 1):
    if(i % 3 == 0):
        print(i)


        