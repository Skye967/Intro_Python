from flask import Flask, render_template
app = Flask(__name__)  

@app.route('/')                           
def hello_world():
    return render_template("checkerboard.html", times=8)
@app.route('/4')                           
def hello_world2():
    return render_template("checkerboard.html", times=4)
@app.route('/<x>/<y>')                           
def hello_world3(x,y):
    return render_template("checkerboard.html", a=int(x), b=int(y))



if __name__=="__main__":
    app.run(debug=True) 