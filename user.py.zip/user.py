class myclass:
    
    def __init__(self, name, acount_balance):
        self.name = name
        self.acount_balance = acount_balance
    def full_information(self):
        return '{} {}'.format(self.name, self.acount_balance)
    def make_withdrawl(self, amount):
        self.acount_balance -= amount
    def make_deposit(self, amount):
        self.acount_balance += amount
    def transfer_money(self, other_user, amount):
        self.acount_balance -= amount
        other_user.acount_balance += amount
    
guido = myclass("Guido van Rossum", 3000)
monty = myclass("Monty Python", 5000)
samson = myclass("Samson Delila", 10000)

guido.make_deposit(100)
guido.make_deposit(200)
guido.make_deposit(300)
print(guido.acount_balance)
monty.make_deposit(1000)
monty.make_deposit(1000)
monty.make_withdrawl(100)
monty.make_withdrawl(100)
print(monty.acount_balance)
samson.make_deposit(500)
samson.make_withdrawl(1000)
samson.make_withdrawl(1000)
samson.make_withdrawl(1000)
print(samson.acount_balance)
samson.transfer_money(monty, 5000)   
print(monty.acount_balance)
print(samson.acount_balance)