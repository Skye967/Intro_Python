x = [ [5,2,3], [10,8,9] ] 
students = [
     {'first_name':  'Michael', 'last_name' : 'Jordan'},
     {'first_name' : 'John', 'last_name' : 'Rosales'}
]
sports_directory = {
    'basketball' : ['Kobe', 'Jordan', 'James', 'Curry'],
    'soccer' : ['Messi', 'Ronaldo', 'Rooney']
}
z = [ {'x': 10, 'y': 20} ]

x[1][0] = 15
students[0]['last_name'] = 'Bryant'
sports_directory['soccer'][0] = 'Andres'
z[0]['y'] = 30



students = [
         {'first_name':  'Michael', 'last_name' : 'Jordan'},
         {'first_name' : 'John', 'last_name' : 'Rosales'},
         {'first_name' : 'Mark', 'last_name' : 'Guillen'},
         {'first_name' : 'KB', 'last_name' : 'Tonel'}
    ]
def iterateDictionary(students):
    for i in range(0,len(students), +1):
        arr1 = []
        arr2 = []
        for key in students[i].keys():
            arr1.append(key)
        for value in students[i].values():
            arr2.append(value)        
        print(arr1[0]+ " - " + arr2[0] + " - " + arr1[1] + " - " + arr2[1])      
        
#iterateDictionary(students)

def iterateDictionary2(students,keyword):        
    for i in range(0,len(students), +1):
        print(students[i][keyword])
        
#iterateDictionary2(students,'last_name') 
dojo = {
   'locations': ['San Jose', 'Seattle', 'Dallas', 'Chicago', 'Tulsa', 'DC', 'Burbank'],
   'instructors': ['Michael', 'Amy', 'Eduardo', 'Josh', 'Graham', 'Patrick', 'Minh', 'Devon']
}

def printInfo(some_dict):
    for i in range(0,len(some_dict)):
        arr1 = []
        arr2 = []
        for key in some_dict.keys():
            arr1.append(key)
        for value in some_dict.values():
            arr2.append(value)
    print(len(arr2[0]))
    print(arr1[0])
    print(', '.join(arr2[0]))
    print(len(arr2[1]))
    print(arr1[1])
    print(', '.join(arr2[1]))
#printInfo(dojo)