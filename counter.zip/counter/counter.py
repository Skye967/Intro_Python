
from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
SESSION_TYPE = 'filesystem'
app.secret_key = 'keep it secret, keep it safe'

@app.route('/')
def index():
    if 'counter' not in session:
        session['counter'] = 0
    return redirect('/users')
            
@app.route('/users')
def create_user():
    session['counter'] += 1
    print(session['counter'])
    return render_template('counter.html' )	

@app.route("/destroy", methods=['POST'])
def show_user():
    session.clear()
    return redirect('/')

if __name__ == "__main__":
    app.run(debug=True)
