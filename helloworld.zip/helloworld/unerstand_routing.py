from flask import Flask  
app = Flask(__name__)    
@app.route('/')          
def hello_world():
    return 'Hello World!'  
@app.route('/say')
def say():
    return 'say'
@app.route('/say/flask')
def say_flask():
    return 'say_flask'
@app.route('/say/michael')
def say_michael():
    return 'say_michael'
@app.route('/say/john')
def say_john():
    return 'say john'
@app.route('/repeat/35/hello')
def hello():
    string = 'hello'
    return ' '.join([string[:5]] * 35)
@app.route('/repeat/80/bye')
def bye():
    string = 'bye'
    return ' '.join([string[:3]] * 80)
@app.route('/repeat/99/dogs')
def dog():
    string = 'dog'
    return ' '.join([string[:3]] * 80)
    




if __name__=="__main__":       
    app.run(debug=True)
    