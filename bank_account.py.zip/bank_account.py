x = []
class BankAccount:
    
    def __init__(self, name, account_balance):
        self.name = name
        self.account_balance = account_balance
        x.append('{} {}'.format(self.name, self.account_balance))
    def full_information(self):
        return '{} {}'.format(self.name, self.account_balance)
    def withdrawl(self, amount):
        self.account_balance -= amount
        return self
    def deposit(self, amount):
        self.account_balance += amount
        return self
    def yield_interest(self):
        self.account_balance = (self.account_balance * 0.01) + self.account_balance
        return self
    @classmethod
    def all_instances(cls):
        print(x)
        
    
guido = BankAccount("Guido van Rossum", 3000)
monty = BankAccount("Monty Python", 5000)

print(guido.deposit(1000).deposit(100).deposit(200).withdrawl(500).yield_interest().full_information())

print(monty.deposit(1000).deposit(1000).withdrawl(100).withdrawl(200).yield_interest().full_information())

BankAccount.all_instances()