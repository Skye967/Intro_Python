Directory = []
def student_directory():
    amount = input("How many students do you have?: ")
    studentamount = int(amount)
    for i in range(studentamount):
        addkeys = ('name', 'grade', 'course')
        adddict = dict.fromkeys(addkeys)
        Directory.append(adddict)
        name = input("Students name: ")
        Directory[i]['name'] = name
        grade = input("Students grade: ")
        Directory[i]['grade'] = grade
        course = input("Enter 1 for Math, 2 for Science, 3 for History: ")
        if(course == '1'):
            course = 'Math'
        if(course == '2'):
            course = 'Science'
        if(course == '3'):
            course = 'History'
        Directory[i]['course'] = course
    print( len(Directory), " Students")
    for j in range(len(Directory)):
        print("name: " + Directory[j]['name']," grade: " + Directory[j]['grade'], " course: " + Directory[j]['course'])
student_directory()  